
public class REQUEST {
	
	public static final String CONNECT = "#CONNECT#";
	public static final String GET = "#GET#";
	public static final String POST = "#POST#";
	public static final String DISCONNECT = "DISCONNECT";
	

	public REQUEST() {
		// TODO Auto-generated constructor stub
	}

}
