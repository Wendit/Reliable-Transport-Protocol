
public class ConnectionAbortEarlyException extends Exception{
	public ConnectionAbortEarlyException( String message) {
		super(message);
	}
}
