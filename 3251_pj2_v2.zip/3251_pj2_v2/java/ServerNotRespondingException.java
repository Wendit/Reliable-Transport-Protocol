
public class ServerNotRespondingException extends Exception{
	public ServerNotRespondingException( String message) {
		super(message);
	}
}
