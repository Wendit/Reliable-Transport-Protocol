
public class PacketCorruptedException extends Exception{

	public PacketCorruptedException(String message) {
		super(message);
	}

}
