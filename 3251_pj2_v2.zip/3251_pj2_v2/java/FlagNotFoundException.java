
public class FlagNotFoundException extends Exception{

	public FlagNotFoundException( String message) {
		super(message);
	}

}
