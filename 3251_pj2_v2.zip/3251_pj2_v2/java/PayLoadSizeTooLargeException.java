
public class PayLoadSizeTooLargeException extends Exception{

	public PayLoadSizeTooLargeException(String message) {
		super(message);
	}

}
